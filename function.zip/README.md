# german-online-assessment-backend
AWS Lambda backend
